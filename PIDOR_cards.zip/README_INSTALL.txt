PIDOR Ornamental Cards

Unzip into the GitHub repository root.
Expected paths: client/public/cards/06_C.webp ... BACK_COMMON.webp
After commit, Cloudflare CI automatically builds and deploys.
All art keeps transparent corners and matches the original 2:3 aspect ratio.
